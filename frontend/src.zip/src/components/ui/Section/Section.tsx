import type { ReactNode } from "react";
import clsx from "clsx";

interface SectionProps {
  children: ReactNode;
  id?: string;
  className?: string;
  variant?: "hero" | "default" | "compact";
}

const Section = ({
  children,
  id,
  className,
  variant = "default",
}: SectionProps) => {
  return (
    <section
      id={id}
      className={clsx(
        "scroll-mt-20",
        {
          "py-10 sm:py-12 lg:py-16": variant === "compact",
          "py-14 sm:py-16 lg:py-20": variant === "default",
          "py-12 sm:py-16 lg:py-18": variant === "hero",
        },
        className
      )}
    >
      {children}
    </section>
  );
};

export default Section;