import Container from "../../components/ui/Container";
import Button from "../../components/ui/Button";
import Section from "../../components/ui/Section";
import Heading from "../../components/ui/Heading";
import Text from "../../components/ui/Text";
import Badge from "../../components/ui/Badge";
import FadeIn from "../../components/animations/FadeIn";
import TechnologyStack from "./components/TechnologyStack";
import ExpertiseChips from "./components/ExpertiseChips";
import { FiDownload, FiMessageSquare } from "react-icons/fi";

const Hero = () => {
    return (
        <Section
            id="hero"
            variant="hero"
            className="bg-red-500/10"
        >
            <Container>
                <FadeIn>
                    <div className="mx-auto flex max-w-5xl flex-col justify-center lg:min-h-[48vh]">

                        <Badge className="mb-3 w-fit self-center text-cyan-400 lg:self-start">
                            16+ Years of Automation Excellence
                        </Badge>

                        <Heading className="text-center lg:text-left">
                            Moshin Kondkari
                        </Heading>

                        <h2 className="mt-3 text-center text-lg font-semibold text-slate-300 lg:text-left lg:text-2xl">
                            Senior Automation Engineer
                        </h2>

                        <div className="mt-5">
                            <ExpertiseChips />
                        </div>

                        <Text className="mx-auto mt-6 max-w-2xl text-center lg:mx-0 lg:text-left">
                            Building scalable automation frameworks and quality
                            engineering solutions for mission-critical financial
                            platforms using Java, Microservices, Cloud technologies,
                            and modern DevOps practices.
                        </Text>

                        <div className="mt-6">
                            <TechnologyStack />
                        </div>

                        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center lg:justify-start">
                            <a
                                href="/moshin-kondkari-resume.pdf"
                                download
                            >
                                <Button>
                                    <FiDownload size={18} />
                                    <span>Download Resume</span>
                                </Button>
                            </a>

                            <a href="#contact">
                                <Button variant="outline">
                                    <FiMessageSquare size={18} />
                                    <span>Let's Connect</span>
                                </Button>
                            </a>
                        </div>
                    </div>
                </FadeIn>
            </Container>
        </Section>
    );
};

export default Hero;