import { TECHNOLOGIES } from "../constants/technology.data";

const TechnologyStack = () => {
    return (
        <div className="mt-6 flex flex-wrap justify-center gap-2.5 lg:justify-start">
            {TECHNOLOGIES.map(({ icon: Icon, label }) => (
                <div
                    key={label}
                    className="flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/50 px-3 py-1.5 text-xs font-medium text-slate-300 transition-all duration-200 hover:border-cyan-400 hover:bg-slate-800/70"
                >
                    {Icon && (
                        <Icon
                            className="text-cyan-400"
                            size={14}
                        />
                    )}

                    <span>{label}</span>
                </div>
            ))}
        </div>
    );
};

export default TechnologyStack;